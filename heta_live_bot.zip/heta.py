#!/usr/bin/env python3
"""
HETA — live Delta Exchange India ETHUSD bot.

Strategy:
- Product 3136 (ETHUSD).
- On a genuinely fresh start, market-buy 10 lots.
- Place 1-lot sell orders at $1 increments above the average entry price,
  up to the 10-lot position cap.
- Whenever a HETA sell fills, place a 1-lot buyback $10 below that sell.
- Whenever that HETA buyback fills, place a 1-lot sell $10 above the buyback.
- Never cancel or manage orders that do not carry HETA's client_order_id prefix.
- Persist order IDs/state locally so a process restart does not intentionally
  reinitialize the strategy.

Important: This is live-trading software. Start only after checking API credentials,
the product, account position, and the strategy parameters. The bot refuses to
initialize if an ETHUSD position already exists, because it cannot safely assume
that position belongs to HETA.
"""

import hashlib
import hmac
import json
import logging
import os
import time
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
from urllib.parse import urlencode

import boto3
import requests

BOT = "HETA"
PREFIX = "HETA-"
BASE_URL = os.getenv("DELTA_BASE_URL", "https://api.india.delta.exchange").rstrip("/")
REGION = os.getenv("AWS_REGION", "ap-south-1")
SECRET_NAME = os.getenv("AWS_SECRET_NAME", "Bhavu")
PRODUCT_ID = int(os.getenv("PRODUCT_ID", "3136"))
SYMBOL = os.getenv("SYMBOL", "ETHUSD")
LIVE = os.getenv("HETA_LIVE_TRADING", "true").lower() == "true"
POLL_SECONDS = int(os.getenv("POLL_SECONDS", "5"))
INITIAL_SIZE = int(os.getenv("INITIAL_SIZE", "10"))
MAX_POSITION = int(os.getenv("MAX_POSITION", "10"))
SELL_STEP = Decimal(os.getenv("SELL_STEP", "1"))
REBUY_DISTANCE = Decimal(os.getenv("REBUY_DISTANCE", "10"))
ORDER_SIZE = int(os.getenv("ORDER_SIZE", "1"))
STATE_FILE = Path(os.getenv("HETA_STATE_FILE", "heta_state.json"))
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO").upper()

logging.basicConfig(
    level=getattr(logging, LOG_LEVEL, logging.INFO),
    format="%(asctime)s %(levelname)s HETA: %(message)s",
)
log = logging.getLogger(BOT)


def load_credentials():
    """Read Delta credentials from AWS Secrets Manager; never print them."""
    raw = boto3.client("secretsmanager", region_name=REGION).get_secret_value(
        SecretId=SECRET_NAME
    )["SecretString"]
    data = json.loads(raw)
    key = next((data[k] for k in ("DELTA_API_KEY", "api_key", "API_KEY", "key") if data.get(k)), None)
    secret = next((data[k] for k in ("DELTA_API_SECRET", "api_secret", "API_SECRET", "secret") if data.get(k)), None)
    if not key or not secret:
        raise RuntimeError(
            f"AWS secret '{SECRET_NAME}' must contain API key and secret fields "
            "(DELTA_API_KEY/DELTA_API_SECRET, api_key/api_secret, or API_KEY/API_SECRET)."
        )
    return key, secret


class Delta:
    def __init__(self, api_key, api_secret):
        self.api_key = api_key
        self.api_secret = api_secret
        self.session = requests.Session()
        self.session.headers.update({
            "Accept": "application/json",
            "Content-Type": "application/json",
            "User-Agent": "heta-live-bot/1.0",
        })

    def request(self, method, path, params=None, body=None, auth=True):
        params = params or {}
        # Keep the signed query string identical to the one sent over HTTP.
        query = urlencode(sorted((k, str(v)) for k, v in params.items()))
        query_part = ("?" + query) if query else ""
        body_text = json.dumps(body, separators=(",", ":"), ensure_ascii=False) if body is not None else ""
        headers = {}
        if auth:
            ts = str(int(time.time()))
            message = method.upper() + ts + path + query_part + body_text
            signature = hmac.new(
                self.api_secret.encode(), message.encode(), hashlib.sha256
            ).hexdigest()
            headers.update({"api-key": self.api_key, "timestamp": ts, "signature": signature})
        url = BASE_URL + path + query_part
        response = self.session.request(
            method.upper(), url, headers=headers,
            data=body_text if body is not None else None, timeout=(5, 25)
        )
        try:
            payload = response.json()
        except Exception:
            response.raise_for_status()
            raise RuntimeError(f"Non-JSON response from Delta (HTTP {response.status_code})")
        if response.status_code >= 400 or payload.get("success") is False:
            raise RuntimeError(f"Delta API error HTTP {response.status_code}: {payload}")
        return payload.get("result", payload)

    def ticker(self):
        result = self.request("GET", f"/v2/tickers/{SYMBOL}", auth=False)
        if isinstance(result, list):
            result = result[0]
        price = result.get("mark_price") or result.get("close") or result.get("last_price")
        if price is None:
            raise RuntimeError(f"Could not read current price from ticker: {result}")
        return Decimal(str(price))

    def position_size(self):
        result = self.request("GET", "/v2/positions", params={"product_id": PRODUCT_ID})
        rows = result if isinstance(result, list) else result.get("positions", result.get("data", []))
        for row in rows or []:
            if int(row.get("product_id", -1)) == PRODUCT_ID:
                # Delta positions are often signed: positive long, negative short.
                return int(Decimal(str(row.get("size", 0))))
        return 0

    def open_orders(self):
        result = self.request("GET", "/v2/orders", params={"product_id": PRODUCT_ID, "state": "open"})
        if isinstance(result, list):
            return result
        return result.get("orders", result.get("data", [])) or []

    def order_by_id(self, order_id):
        return self.request("GET", f"/v2/orders/{order_id}")

    def place(self, side, size, order_type, price=None, client_id=None, reduce_only=False):
        body = {
            "product_id": PRODUCT_ID,
            "size": int(size),
            "side": side,
            "order_type": order_type,
            "client_order_id": client_id,
        }
        if price is not None:
            body["limit_price"] = str(price)
        if reduce_only:
            body["reduce_only"] = True
        return self.request("POST", "/v2/orders", body=body)

    def cancel(self, order_id):
        return self.request("DELETE", f"/v2/orders/{order_id}")


def save_state(state):
    temp = STATE_FILE.with_suffix(".tmp")
    temp.write_text(json.dumps(state, indent=2), encoding="utf-8")
    temp.replace(STATE_FILE)


def load_state():
    if not STATE_FILE.exists():
        return None
    return json.loads(STATE_FILE.read_text(encoding="utf-8"))


def get_order_id(result):
    if isinstance(result, dict):
        if "id" in result:
            return str(result["id"])
        if isinstance(result.get("order"), dict) and result["order"].get("id"):
            return str(result["order"]["id"])
    raise RuntimeError(f"Order response did not include an order ID: {result}")


def order_status(order):
    return str(order.get("state") or order.get("status") or "").lower()


def order_price(order):
    return Decimal(str(
        order.get("average_fill_price")
        or order.get("avg_fill_price")
        or order.get("limit_price")
        or 0
    ))


def is_filled(order):
    """Avoid treating a merely cancelled/part-filled 'closed' order as filled."""
    state = order_status(order)
    if state in ("filled", "completed"):
        return True
    if state != "closed":
        return False
    # Delta order payloads expose unfilled_size; a cancelled order usually has
    # a positive remainder. Require zero remainder when the field is present.
    if order.get("unfilled_size") is not None:
        try:
            return Decimal(str(order["unfilled_size"])) == 0
        except Exception:
            return False
    # If no fill fields are present, fail closed rather than inventing a fill.
    if order.get("filled_size") is not None and order.get("size") is not None:
        try:
            return Decimal(str(order["filled_size"])) >= Decimal(str(order["size"]))
        except Exception:
            return False
    return False


def main():
    if not LIVE:
        raise RuntimeError("HETA_LIVE_TRADING must be true for this live bot.")
    if INITIAL_SIZE > MAX_POSITION or ORDER_SIZE != 1:
        raise RuntimeError("Invalid config: INITIAL_SIZE must be <= MAX_POSITION and ORDER_SIZE must be 1.")
    if SELL_STEP <= 0 or REBUY_DISTANCE <= 0:
        raise RuntimeError("SELL_STEP and REBUY_DISTANCE must be positive.")

    api_key, api_secret = load_credentials()
    api = Delta(api_key, api_secret)
    state = load_state()

    if state is None:
        current_pos = api.position_size()
        if current_pos != 0:
            raise RuntimeError(
                f"Refusing fresh initialization: account already has {current_pos} ETHUSD lots. "
                "Flatten/identify the position and remove no state unless you intentionally want a fresh start."
            )
        price = api.ticker()
        log.warning("FRESH LIVE START: market-buying %s lots of %s.", INITIAL_SIZE, SYMBOL)
        result = api.place("buy", INITIAL_SIZE, "market_order", client_id=PREFIX + "INIT-" + str(int(time.time())))
        init_id = get_order_id(result)
        state = {
            "bot": BOT,
            "product_id": PRODUCT_ID,
            "symbol": SYMBOL,
            "initial_order_id": init_id,
            "initial_price_reference": str(price),
            "initialized": False,
            "orders": {},
            "created_at": int(time.time()),
        }
        save_state(state)
        log.info("Initial market order submitted: id=%s; waiting for fill.", init_id)

    while True:
        try:
            # Wait for the initial market order to fill before seeding sell ladder.
            if not state.get("initialized"):
                order = api.order_by_id(state["initial_order_id"])
                status = order_status(order)
                if is_filled(order):
                    fill_price = order_price(order)
                    if fill_price <= 0:
                        fill_price = Decimal(state["initial_price_reference"])
                    # Sell one lot at each $1 step, capped at the initial 10-lot inventory.
                    for i in range(1, INITIAL_SIZE + 1):
                        target = (fill_price + SELL_STEP * i).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
                        cid = f"{PREFIX}S-{int(time.time())}-{i}"
                        placed = api.place("sell", ORDER_SIZE, "limit_order", target, cid, reduce_only=True)
                        oid = get_order_id(placed)
                        state["orders"][oid] = {
                            "client_order_id": cid, "side": "sell", "price": str(target),
                            "role": "initial_sell", "handled": False
                        }
                        save_state(state)
                    state["initialized"] = True
                    state["entry_price"] = str(fill_price)
                    save_state(state)
                    log.info("Initial buy filled around %s; seeded %s one-lot sell orders.", fill_price, INITIAL_SIZE)
                elif status in ("rejected", "cancelled", "canceled"):
                    raise RuntimeError(f"Initial market order ended with status {status}; stopping.")
                else:
                    time.sleep(POLL_SECONDS)
                    continue

            open_orders = api.open_orders()
            open_ids = {str(o.get("id")) for o in open_orders if o.get("id") is not None}
            # Detect fills by querying every HETA order whose ID is no longer open.
            for oid, meta in list(state["orders"].items()):
                if meta.get("handled") or oid in open_ids:
                    continue
                try:
                    order = api.order_by_id(oid)
                except Exception as e:
                    log.warning("Could not check order %s yet: %s", oid, e)
                    continue
                status = order_status(order)
                if not is_filled(order):
                    # It may have been cancelled; do not create a counter-order.
                    if status in ("cancelled", "canceled", "rejected", "closed"):
                        meta["handled"] = True
                        meta["terminal_status"] = status
                        save_state(state)
                    continue

                meta["handled"] = True
                meta["fill_price"] = str(order_price(order) or Decimal(meta.get("price", "0")))
                save_state(state)

                fill_price = Decimal(meta["fill_price"])
                if meta["side"] == "sell":
                    target = (fill_price - REBUY_DISTANCE).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
                    # Buyback order is not reduce-only; it restores one lot sold by HETA.
                    cid = f"{PREFIX}B-{int(time.time())}-{oid}"
                    placed = api.place("buy", ORDER_SIZE, "limit_order", target, cid)
                    new_id = get_order_id(placed)
                    state["orders"][new_id] = {
                        "client_order_id": cid, "side": "buy", "price": str(target),
                        "role": "buyback", "parent_order_id": oid, "handled": False
                    }
                    save_state(state)
                    log.info("Sell %s filled; placed one-lot buyback at %s (order %s).", oid, target, new_id)
                elif meta["side"] == "buy" and meta.get("role") == "buyback":
                    target = (fill_price + REBUY_DISTANCE).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
                    cid = f"{PREFIX}S-{int(time.time())}-{oid}"
                    placed = api.place("sell", ORDER_SIZE, "limit_order", target, cid, reduce_only=True)
                    new_id = get_order_id(placed)
                    state["orders"][new_id] = {
                        "client_order_id": cid, "side": "sell", "price": str(target),
                        "role": "recycle_sell", "parent_order_id": oid, "handled": False
                    }
                    save_state(state)
                    log.info("Buyback %s filled; placed one-lot resell at %s (order %s).", oid, target, new_id)

            time.sleep(POLL_SECONDS)
        except KeyboardInterrupt:
            log.warning("Stop requested. HETA will exit without cancelling any orders.")
            return
        except Exception:
            log.exception("Loop error; keeping state and retrying after %ss.", POLL_SECONDS)
            time.sleep(POLL_SECONDS)


if __name__ == "__main__":
    main()
