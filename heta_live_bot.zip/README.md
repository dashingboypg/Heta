# HETA — Delta Exchange India live ETHUSD bot

## Files
- `heta.py`: live trading process
- `requirements.txt`: Python dependencies
- `.env.example`: environment variables (do not put API secrets here)

## AWS secret
The secret named `Bhavu` in region `ap-south-1` must be a JSON secret with the Delta API key and secret in one of these forms:
- `DELTA_API_KEY` and `DELTA_API_SECRET`
- `api_key` and `api_secret`
- `API_KEY` and `API_SECRET`

The EC2 instance needs an IAM role permitting `secretsmanager:GetSecretValue` for that secret. Do not paste credentials into chat or commit them to GitHub.

## Strategy
On an empty ETHUSD position and no saved state, HETA submits a market buy for 10 lots, then seeds 1-lot reduce-only sells at $1 increments above the reported entry price. Each HETA sell fill creates a 1-lot buyback $10 below its fill; each HETA buyback fill creates a 1-lot reduce-only sell $10 above its fill. HETA never cancels orders and does not intentionally manage orders lacking its HETA client-order-ID prefix.

## Critical deployment notes
- Live trading is enabled by `HETA_LIVE_TRADING=true`.
- `heta_state.json` is essential for restart recovery. Keep it in the same working directory; back it up before changing/deleting it.
- The script refuses a fresh initialization if it detects a nonzero ETHUSD position. It does not infer that an existing position belongs to HETA.
- This first implementation must be validated against your account's actual Delta API responses before relying on it with real funds. In particular, verify order-status values and the positions endpoint response for product 3136. Do not delete `heta_state.json` to restart the process; that can cause another initial market buy.
- PM2 example after uploading files and installing requirements:
  `pm2 start heta.py --name heta --interpreter python3`
  `pm2 save`
